
package lk.ijse.lms.dao.custom.impl;


import lk.ijse.lms.dao.custom.LoginDAO;
import lk.ijse.lms.entity.Login;
import lk.ijse.lms.entity.User;
import lk.ijse.lms.util.SessionFactoryConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;

import org.hibernate.query.Query;
import java.util.List;

public class LoginDAOImpl implements LoginDAO {
    public User verify(Login login) {
        Session session = SessionFactoryConfig.getInstance().getSession();
        Transaction transaction= session.beginTransaction();
        String nic = login.getNic();
        String password = login.getPassword();

        String sql="SELECT u FROM User u WHERE u.nic= :nic ";
        Query query=session.createQuery(sql).setParameter("nic",nic);
        User user = (User) query.uniqueResult();
        session.close();
        return user;

    }
}

