package lk.ijse.lms.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.lms.bo.BOFactory;
import lk.ijse.lms.bo.custom.UserBO;
import lk.ijse.lms.dto.UserDTO;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

public class UserRegController {
    UserBO userBO= (UserBO)BOFactory.getInstance().getBO(BOFactory.BOTypes.USER);

    @FXML
    private Button btnExit;

    @FXML
    private Button btnSave;

    @FXML
    private DatePicker dateOfBirth;

    @FXML
    private AnchorPane root;

    @FXML
    private TextField txtAddress;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtNic;

    @FXML
    private TextField txtTel;
    @FXML
    private TextField txtPass;

    @FXML
    void btnExitOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Library Management System");
        stage.centerOnScreen();
        stage.show();

    }

    @FXML
    void btnSaveOnAction(ActionEvent event) throws IOException {
        int id=0;
        String name=txtName.getText();
        String address=txtAddress.getText();
        String tel=txtTel.getText();
        String nic=txtNic.getText();
        LocalDate dob=dateOfBirth.getValue();
        String password=txtPass.getText();
        int status=1;


        UserDTO userDTO=new UserDTO(id,name,address,tel,nic,dob,password,status);
        boolean ifsaved =userBO.saveUser(userDTO);
        if(ifsaved){
            new Alert(Alert.AlertType.INFORMATION,"User Is Saved").show();
            AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
            Scene scene = new Scene(anchorPane);
            Stage stage = (Stage) root.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Library Management System");
            stage.centerOnScreen();
            stage.show();



        }else{
            new Alert(Alert.AlertType.CONFIRMATION,"User Is Not-Saved").show();
        }

    }

}
