package lk.ijse.lms.bo.custom;

import lk.ijse.lms.bo.SuperBO;
import lk.ijse.lms.dto.LoginDTO;

import java.sql.SQLException;

public interface LoginBO extends SuperBO {
    int verify(LoginDTO loginDTO) throws SQLException;
}
