package lk.ijse.lms.dao;

import lk.ijse.lms.bo.custom.impl.LoginBOImpl;
import lk.ijse.lms.dao.custom.impl.LoginDAOImpl;
import lk.ijse.lms.dao.custom.impl.UserDAOImpl;

import static lk.ijse.lms.bo.BOFactory.BOTypes.LOGIN;

public class DAOFactory {
    private static DAOFactory daoFactory;

    private DAOFactory() {
    }

    public static DAOFactory getInstance() {
        return daoFactory == null ? new DAOFactory() : daoFactory;
    }

    public enum DAOTypes {
        USER,LOGIN,ADMIN
    }

    public SuperDAO  getDAO(DAOTypes types) {
        switch (types) {
            case USER:
                return  new UserDAOImpl();
            case LOGIN:
                return new LoginDAOImpl();
//            case ADMIN:
//                return new AdminDAOImpl();
            default:
                return null;
        }
    }
}
