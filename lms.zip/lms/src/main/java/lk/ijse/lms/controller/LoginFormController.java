package lk.ijse.lms.controller;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import lk.ijse.lms.bo.BOFactory;
import lk.ijse.lms.bo.custom.LoginBO;
import lk.ijse.lms.dto.LoginDTO;

import java.io.IOException;
import java.sql.SQLException;

public class LoginFormController {

    LoginBO loginBO= (LoginBO) BOFactory.getInstance().getBO(BOFactory.BOTypes.LOGIN);

    @FXML
    private Button btnLogin;

    @FXML
    private TextField txtNic;

    @FXML
    private TextField txtPassword;
    @FXML
    private AnchorPane root;
    @FXML
    private Button btnSignup;
    @FXML
    void btnSignupOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/userReg.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Library Management System");
        stage.centerOnScreen();
        stage.show();


    }

    @FXML
    void btnLoginOnAction(ActionEvent event) throws SQLException, IOException {
        String nic=txtNic.getText();
        String password=txtPassword.getText();
        LoginDTO loginDTO=new LoginDTO(nic,password,0);
        int isVerify=loginBO.verify(loginDTO);
        System.out.println(isVerify);

//        AnchorPane anchorPane=null;

        if(isVerify==1){
            AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/userDashboard.fxml"));
            Scene scene = new Scene(anchorPane);
            Stage stage = (Stage) root.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Library Management System");
            stage.centerOnScreen();
            stage.show();
        } else if (isVerify==2) {
            AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/adminDashboard.fxml"));
            Scene scene = new Scene(anchorPane);
            Stage stage = (Stage) root.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Library Management System");
            stage.centerOnScreen();
            stage.show();
        }else{
            AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
            Scene scene = new Scene(anchorPane);
            Stage stage = (Stage) root.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Library Management System");
            stage.centerOnScreen();
            stage.show();
            new Alert(Alert.AlertType.INFORMATION, "NIC or Password Incorrect!").show();
        }



    }
}
