package lk.ijse.lms.bo.custom;

import lk.ijse.lms.bo.SuperBO;
import lk.ijse.lms.dto.UserDTO;

import java.util.List;

public interface UserBO extends SuperBO {
    boolean saveUser(UserDTO userDTO);
    boolean updateUser(UserDTO userDTO);
    boolean deleteUser(int id);
    UserDTO searchUser(String nic);
    List<UserDTO> getAllUser();
}
