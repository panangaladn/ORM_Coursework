package lk.ijse.lms.dao.custom;

import lk.ijse.lms.dao.CrudDAO;
import lk.ijse.lms.entity.User;

public interface UserDAO extends CrudDAO<User> {
}
