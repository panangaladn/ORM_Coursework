package lk.ijse.lms.bo.custom.impl;

import lk.ijse.lms.bo.custom.LoginBO;
import lk.ijse.lms.dao.DAOFactory;
import lk.ijse.lms.dao.custom.LoginDAO;
import lk.ijse.lms.dto.LoginDTO;
import lk.ijse.lms.entity.Login;
import lk.ijse.lms.entity.User;

import java.sql.SQLException;

import static lk.ijse.lms.dao.DAOFactory.DAOTypes.LOGIN;

public class LoginBOImpl implements LoginBO {
    LoginDAO loginDAO= (LoginDAO) DAOFactory.getInstance().getDAO(LOGIN);
    @Override
    public int verify(LoginDTO loginDTO) throws SQLException {
        Login login=new Login(loginDTO.getNic(), loginDTO.getPassword(), loginDTO.getStatus());
        User user=loginDAO.verify(login);
        if(user!=null){
            int status=user.getStatus();
            return status;
        }
        return 0;
    }
}
