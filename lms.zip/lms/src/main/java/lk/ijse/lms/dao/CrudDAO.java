package lk.ijse.lms.dao;

import java.util.List;

public interface CrudDAO<T> extends SuperDAO {
    boolean save(T entity);
    boolean update(T entity);
    boolean delete(int id);
    T search(String nic);
    List<T> gelAll();
}
