package lk.ijse.lms.dao;

public interface SuperDAO {
}
