package lk.ijse.lms.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class UserashboardFormController {


    @FXML
    private Button btnBorrow;

    @FXML
    private Button btnCP;

    @FXML
    private Button btnHistory;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnProfile;

    @FXML
    private Button btnReport;

    @FXML
    private Button btnReturn;

    @FXML
    private AnchorPane root;

    @FXML
    void btnBorrowOnAction(ActionEvent event) {

    }

    @FXML
    void btnCPOnAction(ActionEvent event) {

    }

    @FXML
    void btnHistoryOnAction(ActionEvent event) {

    }

    @FXML
    void btnLogoutOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Library Management System");
        stage.centerOnScreen();
        stage.show();

    }

    @FXML
    void btnProfileOnAction(ActionEvent event) {

    }

    @FXML
    void btnReportOnAction(ActionEvent event) {

    }

    @FXML
    void btnReturnOnAction(ActionEvent event) {

    }
}
