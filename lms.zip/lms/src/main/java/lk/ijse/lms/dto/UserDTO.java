package lk.ijse.lms.dto;

import java.time.LocalDate;

public class UserDTO {
    private int id;
    private String name;
    private String address;
    private String tel;
    private String  nic;
    private LocalDate dOfb;
    private int status;
    private String password;


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserDTO(int id, String name, String address, String tel, String nic, LocalDate dOfb, String password, int status) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.tel = tel;
        this.nic = nic;
        this.dOfb = dOfb;
        this.password=password;
        this.status=status;
    }

    public UserDTO() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public LocalDate getdOfb() {
        return dOfb;
    }

    public void setdOfb(LocalDate dOfb) {
        this.dOfb = dOfb;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
