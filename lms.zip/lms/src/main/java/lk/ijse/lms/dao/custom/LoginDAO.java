package lk.ijse.lms.dao.custom;

import lk.ijse.lms.dao.CrudDAO;
import lk.ijse.lms.dao.SuperDAO;
import lk.ijse.lms.entity.Login;
import lk.ijse.lms.entity.User;

import java.sql.SQLException;
import java.util.List;

public interface LoginDAO extends SuperDAO {
  User verify(Login login) throws SQLException;
}
