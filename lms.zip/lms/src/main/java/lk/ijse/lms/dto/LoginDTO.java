package lk.ijse.lms.dto;

public class LoginDTO {
    private String nic;
    private String password;
    private int status;


    public LoginDTO(String nic, String password, int status) {
        this.nic = nic;
        this.password = password;
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public LoginDTO() {
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
