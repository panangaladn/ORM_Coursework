package lk.ijse.lms.dao.custom.impl;

import lk.ijse.lms.dao.custom.UserDAO;
import lk.ijse.lms.entity.User;
import lk.ijse.lms.util.SessionFactoryConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class UserDAOImpl implements UserDAO {
    @Override
    public boolean save(User entity) {
        Session session= SessionFactoryConfig.getInstance().getSession();
        Transaction transaction=session.beginTransaction();
        try {
            session.save(entity);
            transaction.commit();
            return true;

        }catch (Exception e){
            transaction.rollback();
            return false;
        }
        finally {
            session.close();
        }
    }

    @Override
    public boolean update(User entity) {

        Session session= SessionFactoryConfig.getInstance().getSession();
        Transaction transaction=session.beginTransaction();
        try {
            session.update(entity);
            transaction.commit();
            return true;

        }catch (Exception e){
            transaction.rollback();
            return false;
        }
        finally {
            session.close();
        }
    }

    @Override
    public boolean delete(int id) {

        Session session= SessionFactoryConfig.getInstance().getSession();
        Transaction transaction=session.beginTransaction();
        try {
            User delUser=session.get(User.class,id);
            session.delete(delUser);
            transaction.commit();
            return true;

        }catch (Exception e){
            transaction.rollback();
            return false;
        }
        finally {
            session.close();
        }
    }

    @Override
    public User search(String nic) {
        Session session=SessionFactoryConfig.getInstance().getSession();
        try{
            User searchUser=session.get(User.class,nic);
            return searchUser;
        }catch (Exception e){
            return null;
        }
        finally {
            session.close();
        }
    }

    @Override
    public List<User> gelAll() {
       Session session=SessionFactoryConfig.getInstance().getSession();
       String hql="FROM User";
        Query query=session.createQuery(hql);
        List<User> userList=query.list();
        session.close();
        return userList;
    }
}
