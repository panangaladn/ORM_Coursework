package lk.ijse.lms.bo;

public interface SuperBO {
}
