package lk.ijse.lms;

public class AppInitializerWrapper {
    public static void main(String[] args) {
        lk.ijse.lms.AppInitializer.main(args);
    }
}