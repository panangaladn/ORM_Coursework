package lk.ijse.lms.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminDashboardFormController {


    @FXML
    private Button btnBookManage;

    @FXML
    private Button btnCostManage;

    @FXML
    private Button btnLoginManage;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnOthers;

    @FXML
    private Button btnResourceManage;

    @FXML
    private Button btnStaffManage;

    @FXML
    private Button btnUserManage;

    @FXML
    private AnchorPane root;

    @FXML
    void btnBookManageOnAction(ActionEvent event) {

    }

    @FXML
    void btnCostManageOnAction(ActionEvent event) {

    }

    @FXML
    void btnLoginManageOnAction(ActionEvent event) {

    }

    @FXML
    void btnLogoutOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Library Management System");
        stage.centerOnScreen();
        stage.show();

    }

    @FXML
    void btnOthersOnAction(ActionEvent event) {

    }

    @FXML
    void btnResourceManageOnAction(ActionEvent event) {

    }

    @FXML
    void btnStaffManageOnAction(ActionEvent event) {

    }

    @FXML
    void btnUserManageOnAction(ActionEvent event) {

    }
}
