package lk.ijse.lms.bo.custom.impl;

import lk.ijse.lms.bo.custom.UserBO;
import lk.ijse.lms.dao.DAOFactory;
import lk.ijse.lms.dao.custom.UserDAO;
import lk.ijse.lms.dto.UserDTO;
import lk.ijse.lms.entity.User;

import java.util.ArrayList;
import java.util.List;

public class UserBOImpl implements UserBO {
    UserDAO userDAO= (UserDAO) DAOFactory.getInstance().getDAO(DAOFactory.DAOTypes.USER);


    @Override
    public boolean saveUser(UserDTO userDTO) {
        User user=new User(userDTO.getId(),userDTO.getName(),userDTO.getAddress(),userDTO.getTel(),userDTO.getNic(),userDTO.getdOfb(), userDTO.getPassword(), userDTO.getStatus());
        //user.setId(userDTO.getId());
       return userDAO.save(user);
    }

    @Override
    public boolean updateUser(UserDTO userDTO) {
        return false;
    }

    @Override
    public boolean deleteUser(int id) {
       return userDAO.delete(id);
    }

    @Override
    public UserDTO searchUser(String nic) {
        User search = userDAO.search(nic);
        if(search!=null){
            return new UserDTO(search.getId(),search.getName(),search.getAddress(), search.getTel(), search.getNic(), search.getdOfb(), search.getPassword(), search.getStatus());

        }
        return null;
    }

    @Override
    public List<UserDTO> getAllUser() {
        List<User> userList = userDAO.gelAll();
        List<UserDTO> getalluser=new ArrayList<>();
        for (User user:userList
             ) {
            getalluser.add(new UserDTO(user.getId(),user.getName(),user.getAddress(), user.getTel(), user.getNic(),user.getdOfb(), user.getPassword(), user.getStatus()));
        }
        return getalluser;
    }
}
